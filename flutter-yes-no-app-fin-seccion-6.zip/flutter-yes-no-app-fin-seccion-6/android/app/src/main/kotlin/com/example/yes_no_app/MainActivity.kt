package com.example.yes_no_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
